"use client";

import { AttendanceRecord } from "@/lib/attendance-data";
import { cn } from "@/lib/utils";

interface AttendanceHeatmapProps {
  records: AttendanceRecord[];
  dates: string[];
}

export function AttendanceHeatmap({ records, dates }: AttendanceHeatmapProps) {
  // Get unique students
  const students = [...new Set(records.map((r) => r.name))].slice(0, 10);
  const recentDates = dates.slice(-10);

  const getStatus = (studentName: string, date: string) => {
    const record = records.find(
      (r) => r.name === studentName && r.date === date
    );
    return record?.status || null;
  };

  const statusColors = {
    present: "bg-success/80 hover:bg-success",
    absent: "bg-destructive/80 hover:bg-destructive",
    late: "bg-warning/80 hover:bg-warning",
  };

  const formatDate = (date: string) => {
    const d = new Date(date);
    return d.toLocaleDateString("en-US", { weekday: "short", day: "numeric" });
  };

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[600px]">
        {/* Header */}
        <div className="flex items-center gap-2 mb-3">
          <div className="w-32 text-xs font-medium text-muted-foreground">
            Student
          </div>
          {recentDates.map((date) => (
            <div
              key={date}
              className="flex-1 text-center text-xs font-medium text-muted-foreground"
            >
              {formatDate(date)}
            </div>
          ))}
        </div>

        {/* Rows */}
        <div className="space-y-2">
          {students.map((student) => (
            <div key={student} className="flex items-center gap-2">
              <div className="w-32 text-sm text-foreground truncate">
                {student.split(" ")[0]}
              </div>
              {recentDates.map((date) => {
                const status = getStatus(student, date);
                return (
                  <div
                    key={date}
                    className={cn(
                      "flex-1 h-8 rounded-md transition-all cursor-default",
                      status ? statusColors[status] : "bg-muted/30"
                    )}
                    title={`${student} - ${formatDate(date)}: ${
                      status || "No data"
                    }`}
                  />
                );
              })}
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-end gap-4 mt-4 pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-success" />
            <span className="text-xs text-muted-foreground">Present</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-destructive" />
            <span className="text-xs text-muted-foreground">Absent</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-warning" />
            <span className="text-xs text-muted-foreground">Late</span>
          </div>
        </div>
      </div>
    </div>
  );
}
