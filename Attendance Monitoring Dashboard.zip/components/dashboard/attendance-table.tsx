"use client";

import { useState, useMemo } from "react";
import { Student } from "@/lib/attendance-data";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Search,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertTriangle,
} from "lucide-react";

interface AttendanceTableProps {
  students: Student[];
}

type SortField = "name" | "attendancePercentage" | "status" | "studentId";
type SortDirection = "asc" | "desc";
type FilterStatus = "all" | "present" | "absent" | "late" | "at-risk";

export function AttendanceTable({ students }: AttendanceTableProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState<SortField>("studentId");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");

  const filteredAndSortedStudents = useMemo(() => {
    let filtered = students.filter((student) => {
      const matchesSearch =
        student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.studentId.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (filterStatus === "all") return true;
      if (filterStatus === "at-risk") return student.attendancePercentage < 75;
      if (filterStatus === "present") return student.totalPresent > student.totalAbsent;
      if (filterStatus === "absent") return student.totalAbsent > 3;
      if (filterStatus === "late") return student.totalLate > 2;

      return true;
    });

    return filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case "name":
          comparison = a.name.localeCompare(b.name);
          break;
        case "attendancePercentage":
          comparison = a.attendancePercentage - b.attendancePercentage;
          break;
        case "studentId":
          comparison = a.studentId.localeCompare(b.studentId);
          break;
        case "status":
          comparison = a.totalPresent - b.totalPresent;
          break;
      }
      return sortDirection === "asc" ? comparison : -comparison;
    });
  }, [students, searchQuery, sortField, sortDirection, filterStatus]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4" />;
    return sortDirection === "asc" ? (
      <ArrowUp className="h-4 w-4" />
    ) : (
      <ArrowDown className="h-4 w-4" />
    );
  };

  const TrendIcon = ({ trend }: { trend: "up" | "down" | "stable" }) => {
    if (trend === "up") return <TrendingUp className="h-4 w-4 text-success" />;
    if (trend === "down")
      return <TrendingDown className="h-4 w-4 text-destructive" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const filterButtons: { label: string; value: FilterStatus }[] = [
    { label: "All", value: "all" },
    { label: "Good Standing", value: "present" },
    { label: "High Absence", value: "absent" },
    { label: "Frequently Late", value: "late" },
    { label: "At Risk", value: "at-risk" },
  ];

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-4">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by name or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background border-border"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {filterButtons.map((btn) => (
              <Button
                key={btn.value}
                variant={filterStatus === btn.value ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterStatus(btn.value)}
                className={cn(
                  "transition-all",
                  filterStatus === btn.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-background hover:bg-accent"
                )}
              >
                {btn.label}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-muted/30">
              <th className="p-4 text-left">
                <button
                  onClick={() => handleSort("studentId")}
                  className="flex items-center gap-2 font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Student ID
                  <SortIcon field="studentId" />
                </button>
              </th>
              <th className="p-4 text-left">
                <button
                  onClick={() => handleSort("name")}
                  className="flex items-center gap-2 font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Name
                  <SortIcon field="name" />
                </button>
              </th>
              <th className="p-4 text-left">
                <button
                  onClick={() => handleSort("status")}
                  className="flex items-center gap-2 font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Status
                  <SortIcon field="status" />
                </button>
              </th>
              <th className="p-4 text-left">
                <button
                  onClick={() => handleSort("attendancePercentage")}
                  className="flex items-center gap-2 font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Attendance
                  <SortIcon field="attendancePercentage" />
                </button>
              </th>
              <th className="p-4 text-left font-medium text-muted-foreground">
                Trend
              </th>
              <th className="p-4 text-left font-medium text-muted-foreground">
                Alerts
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredAndSortedStudents.map((student, index) => (
              <tr
                key={student.id}
                className={cn(
                  "border-b border-border/50 transition-colors hover:bg-muted/20",
                  student.attendancePercentage < 75 && "bg-destructive/5"
                )}
                style={{
                  animationDelay: `${index * 20}ms`,
                }}
              >
                <td className="p-4">
                  <span className="font-mono text-sm text-muted-foreground">
                    {student.studentId}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-foreground">
                      {student.name}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {student.email}
                    </span>
                  </div>
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center rounded-full bg-success/10 px-2 py-1 text-xs font-medium text-success">
                      {student.totalPresent}P
                    </span>
                    <span className="inline-flex items-center rounded-full bg-destructive/10 px-2 py-1 text-xs font-medium text-destructive">
                      {student.totalAbsent}A
                    </span>
                    <span className="inline-flex items-center rounded-full bg-warning/10 px-2 py-1 text-xs font-medium text-warning">
                      {student.totalLate}L
                    </span>
                  </div>
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all duration-500",
                          student.attendancePercentage >= 90
                            ? "bg-success"
                            : student.attendancePercentage >= 75
                            ? "bg-warning"
                            : "bg-destructive"
                        )}
                        style={{ width: `${student.attendancePercentage}%` }}
                      />
                    </div>
                    <span
                      className={cn(
                        "text-sm font-medium",
                        student.attendancePercentage >= 90
                          ? "text-success"
                          : student.attendancePercentage >= 75
                          ? "text-warning"
                          : "text-destructive"
                      )}
                    >
                      {student.attendancePercentage}%
                    </span>
                  </div>
                </td>
                <td className="p-4">
                  <TrendIcon trend={student.trend} />
                </td>
                <td className="p-4">
                  {student.consecutiveAbsences >= 3 && (
                    <div className="flex items-center gap-2 text-destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="text-xs font-medium">
                        {student.consecutiveAbsences} consecutive absences
                      </span>
                    </div>
                  )}
                  {student.attendancePercentage < 75 &&
                    student.consecutiveAbsences < 3 && (
                      <span className="text-xs text-warning font-medium">
                        Below 75% threshold
                      </span>
                    )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="border-t border-border p-4">
        <p className="text-sm text-muted-foreground">
          Showing {filteredAndSortedStudents.length} of {students.length}{" "}
          students
        </p>
      </div>
    </div>
  );
}
