"use client";

import { Student } from "@/lib/attendance-data";
import { cn } from "@/lib/utils";
import { Trophy, AlertTriangle, TrendingDown, UserCheck } from "lucide-react";

interface InsightsPanelProps {
  students: Student[];
}

export function InsightsPanel({ students }: InsightsPanelProps) {
  const topPerformer = students.reduce((prev, current) =>
    prev.attendancePercentage > current.attendancePercentage ? prev : current
  );

  const atRiskStudents = students.filter(
    (s) => s.attendancePercentage < 75 || s.consecutiveAbsences >= 3
  );

  const likelyToFallBelow = students.filter(
    (s) =>
      s.attendancePercentage >= 75 &&
      s.attendancePercentage < 80 &&
      s.trend === "down"
  );

  const consecutiveAbsenceAlerts = students.filter(
    (s) => s.consecutiveAbsences >= 3
  );

  const insights = [
    {
      icon: Trophy,
      title: "Top Performer",
      description: topPerformer.name,
      value: `${topPerformer.attendancePercentage}%`,
      variant: "success" as const,
    },
    {
      icon: AlertTriangle,
      title: "At Risk Students",
      description: "Below 75% attendance",
      value: atRiskStudents.length.toString(),
      variant: "danger" as const,
    },
    {
      icon: TrendingDown,
      title: "Likely to Fall Below 75%",
      description: "Declining trend detected",
      value: likelyToFallBelow.length.toString(),
      variant: "warning" as const,
    },
    {
      icon: UserCheck,
      title: "Consecutive Absence Alerts",
      description: "3+ days absent in a row",
      value: consecutiveAbsenceAlerts.length.toString(),
      variant: "danger" as const,
    },
  ];

  const variantStyles = {
    success: {
      bg: "bg-success/10",
      text: "text-success",
      border: "border-success/20",
    },
    warning: {
      bg: "bg-warning/10",
      text: "text-warning",
      border: "border-warning/20",
    },
    danger: {
      bg: "bg-destructive/10",
      text: "text-destructive",
      border: "border-destructive/20",
    },
  };

  return (
    <div className="space-y-4">
      {insights.map((insight, index) => {
        const styles = variantStyles[insight.variant];
        return (
          <div
            key={index}
            className={cn(
              "flex items-center gap-4 rounded-lg border p-4 transition-all hover:shadow-md",
              styles.border,
              "bg-card"
            )}
          >
            <div className={cn("rounded-lg p-2.5", styles.bg)}>
              <insight.icon className={cn("h-5 w-5", styles.text)} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-foreground">{insight.title}</p>
              <p className="text-sm text-muted-foreground truncate">
                {insight.description}
              </p>
            </div>
            <div className={cn("text-2xl font-bold", styles.text)}>
              {insight.value}
            </div>
          </div>
        );
      })}

      {atRiskStudents.length > 0 && (
        <div className="mt-6">
          <h4 className="text-sm font-medium text-muted-foreground mb-3">
            At Risk Students Details
          </h4>
          <div className="space-y-2">
            {atRiskStudents.slice(0, 5).map((student) => (
              <div
                key={student.id}
                className="flex items-center justify-between rounded-lg bg-destructive/5 border border-destructive/10 p-3"
              >
                <div>
                  <p className="font-medium text-foreground text-sm">
                    {student.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {student.studentId}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-destructive">
                    {student.attendancePercentage}%
                  </p>
                  {student.consecutiveAbsences >= 3 && (
                    <p className="text-xs text-destructive/80">
                      {student.consecutiveAbsences} consecutive absences
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
