"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface WeeklyTrendsChartProps {
  data: {
    week: string;
    present: number;
    absent: number;
    late: number;
  }[];
}

export function WeeklyTrendsChart({ data }: WeeklyTrendsChartProps) {
  const CustomTooltip = ({
    active,
    payload,
    label,
  }: {
    active?: boolean;
    payload?: Array<{ name: string; value: number; color: string }>;
    label?: string;
  }) => {
    if (active && payload && payload.length) {
      return (
        <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
          <p className="font-medium text-foreground mb-2">Week of {label}</p>
          {payload.map((item, index) => (
            <p key={index} className="text-sm" style={{ color: item.color }}>
              {item.name}: {item.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
        >
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="oklch(0.25 0.01 260)"
            vertical={false}
          />
          <XAxis
            dataKey="week"
            tick={{ fill: "oklch(0.6 0 0)", fontSize: 12 }}
            axisLine={{ stroke: "oklch(0.25 0.01 260)" }}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: "oklch(0.6 0 0)", fontSize: 12 }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            verticalAlign="top"
            height={36}
            formatter={(value) => (
              <span className="text-sm text-foreground capitalize">{value}</span>
            )}
          />
          <Bar
            dataKey="present"
            name="Present"
            fill="oklch(0.7 0.18 160)"
            radius={[4, 4, 0, 0]}
            animationDuration={800}
          />
          <Bar
            dataKey="absent"
            name="Absent"
            fill="oklch(0.65 0.22 25)"
            radius={[4, 4, 0, 0]}
            animationDuration={800}
          />
          <Bar
            dataKey="late"
            name="Late"
            fill="oklch(0.75 0.15 85)"
            radius={[4, 4, 0, 0]}
            animationDuration={800}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
