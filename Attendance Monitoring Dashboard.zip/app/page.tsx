"use client";

import Link from "next/link";
import { ArrowRight, Users, BarChart3, Shield, Sparkles } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
        <div className="container mx-auto px-4 py-6">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">AttendIQ</span>
            </div>

          </nav>
        </div>

        <div className="container mx-auto px-4 py-24 text-center relative">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Role-Based Attendance System
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance">
            Smart Attendance
            <br />
            <span className="text-primary">Monitoring System</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 text-pretty">
            A comprehensive role-based attendance tracking solution with separate dashboards 
            for students and administrators. Built with modern web technologies.
          </p>
          <div className="flex items-center justify-center">
            <Link 
              href="/attendance-system/index.html"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-primary text-primary-foreground font-semibold text-lg hover:opacity-90 transition-opacity shadow-lg shadow-primary/25"
            >
              Open Dashboard
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-24 bg-card border-y border-border">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Powerful Features
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Everything you need to track and manage attendance efficiently
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={Users}
              title="Role-Based Access"
              description="Separate dashboards for students and administrators with appropriate access levels and features."
            />
            <FeatureCard
              icon={BarChart3}
              title="Analytics & Charts"
              description="Visual insights with pie charts, bar charts, and attendance trends to make data-driven decisions."
            />
            <FeatureCard
              icon={Shield}
              title="Smart Alerts"
              description="Automated alerts for low attendance, consecutive absences, and at-risk students."
            />
          </div>
        </div>
      </section>

      {/* Demo Credentials Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="rounded-2xl border border-border bg-card p-8 md:p-12">
              <h3 className="text-2xl font-bold text-foreground mb-2 text-center">
                Try the Demo
              </h3>
              <p className="text-muted-foreground text-center mb-8">
                Use these credentials to explore the system
              </p>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-accent/50">
                  <div>
                    <p className="font-medium text-foreground">Student Account</p>
                    <p className="text-sm text-muted-foreground">View personal attendance</p>
                  </div>
                  <code className="px-3 py-1.5 rounded-lg bg-primary/10 text-primary font-mono text-sm">
                    STU001 / student123
                  </code>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl bg-accent/50">
                  <div>
                    <p className="font-medium text-foreground">Admin Account</p>
                    <p className="text-sm text-muted-foreground">Manage all students</p>
                  </div>
                  <code className="px-3 py-1.5 rounded-lg bg-primary/10 text-primary font-mono text-sm">
                    admin / admin123
                  </code>
                </div>
              </div>

              <div className="mt-8 text-center">
                <Link 
                  href="/attendance-system/index.html"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-opacity"
                >
                  Go to Login
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4">
          <p className="text-center text-sm text-muted-foreground">
            AttendIQ - Smart Attendance Monitoring System. Built with HTML, CSS, and JavaScript.
          </p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ComponentType<{ className?: string }>; 
  title: string; 
  description: string;
}) {
  return (
    <div className="p-6 rounded-xl border border-border bg-background hover:border-primary/50 transition-colors">
      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-primary" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}
