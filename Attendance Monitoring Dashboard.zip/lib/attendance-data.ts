export type AttendanceStatus = "present" | "absent" | "late";

export interface AttendanceRecord {
  id: string;
  studentId: string;
  name: string;
  date: string;
  status: AttendanceStatus;
}

export interface Student {
  id: string;
  studentId: string;
  name: string;
  email: string;
  attendancePercentage: number;
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  consecutiveAbsences: number;
  trend: "up" | "down" | "stable";
}

// Generate sample attendance data
const studentNames = [
  "Emma Johnson",
  "Liam Williams",
  "Olivia Brown",
  "Noah Davis",
  "Ava Martinez",
  "Ethan Garcia",
  "Sophia Rodriguez",
  "Mason Wilson",
  "Isabella Anderson",
  "Lucas Taylor",
  "Mia Thomas",
  "Alexander Jackson",
  "Charlotte White",
  "James Harris",
  "Amelia Martin",
  "Benjamin Thompson",
  "Harper Robinson",
  "William Clark",
  "Evelyn Lewis",
  "Michael Lee",
];

const generateStudentId = (index: number) =>
  `STU${String(index + 1).padStart(4, "0")}`;

const generateDateRange = (days: number): string[] => {
  const dates: string[] = [];
  const today = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    // Skip weekends
    if (date.getDay() !== 0 && date.getDay() !== 6) {
      dates.push(date.toISOString().split("T")[0]);
    }
  }
  return dates;
};

const generateStatus = (studentIndex: number): AttendanceStatus => {
  const rand = Math.random();
  // Some students have higher absence rates
  if (studentIndex % 5 === 0) {
    // At-risk students
    if (rand < 0.35) return "absent";
    if (rand < 0.5) return "late";
    return "present";
  }
  // Regular students
  if (rand < 0.08) return "absent";
  if (rand < 0.15) return "late";
  return "present";
};

export const dates = generateDateRange(30);

export const generateAttendanceRecords = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  let recordId = 1;

  studentNames.forEach((name, studentIndex) => {
    dates.forEach((date) => {
      records.push({
        id: `REC${String(recordId++).padStart(5, "0")}`,
        studentId: generateStudentId(studentIndex),
        name,
        date,
        status: generateStatus(studentIndex),
      });
    });
  });

  return records;
};

export const calculateStudentStats = (
  records: AttendanceRecord[]
): Student[] => {
  const studentMap = new Map<
    string,
    {
      name: string;
      studentId: string;
      records: AttendanceRecord[];
    }
  >();

  records.forEach((record) => {
    if (!studentMap.has(record.studentId)) {
      studentMap.set(record.studentId, {
        name: record.name,
        studentId: record.studentId,
        records: [],
      });
    }
    studentMap.get(record.studentId)!.records.push(record);
  });

  const students: Student[] = [];

  studentMap.forEach((data, id) => {
    const sortedRecords = data.records.sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    const totalPresent = sortedRecords.filter(
      (r) => r.status === "present"
    ).length;
    const totalAbsent = sortedRecords.filter(
      (r) => r.status === "absent"
    ).length;
    const totalLate = sortedRecords.filter((r) => r.status === "late").length;
    const total = sortedRecords.length;

    // Calculate consecutive absences
    let consecutiveAbsences = 0;
    for (const record of sortedRecords) {
      if (record.status === "absent") {
        consecutiveAbsences++;
      } else {
        break;
      }
    }

    // Calculate trend (last 5 days vs previous 5 days)
    const last5 = sortedRecords.slice(0, 5);
    const prev5 = sortedRecords.slice(5, 10);
    const last5Present = last5.filter((r) => r.status === "present").length;
    const prev5Present = prev5.filter((r) => r.status === "present").length;
    let trend: "up" | "down" | "stable" = "stable";
    if (last5Present > prev5Present) trend = "up";
    if (last5Present < prev5Present) trend = "down";

    students.push({
      id,
      studentId: data.studentId,
      name: data.name,
      email: `${data.name.toLowerCase().replace(" ", ".")}@school.edu`,
      attendancePercentage: Math.round(((totalPresent + totalLate * 0.5) / total) * 100),
      totalPresent,
      totalAbsent,
      totalLate,
      consecutiveAbsences,
      trend,
    });
  });

  return students.sort((a, b) => a.studentId.localeCompare(b.studentId));
};

export const getWeeklyTrends = (records: AttendanceRecord[]) => {
  const weeklyData: {
    week: string;
    present: number;
    absent: number;
    late: number;
  }[] = [];

  // Group by week
  const weekMap = new Map<
    string,
    { present: number; absent: number; late: number }
  >();

  records.forEach((record) => {
    const date = new Date(record.date);
    const weekStart = new Date(date);
    weekStart.setDate(date.getDate() - date.getDay());
    const weekKey = weekStart.toISOString().split("T")[0];

    if (!weekMap.has(weekKey)) {
      weekMap.set(weekKey, { present: 0, absent: 0, late: 0 });
    }

    const stats = weekMap.get(weekKey)!;
    if (record.status === "present") stats.present++;
    if (record.status === "absent") stats.absent++;
    if (record.status === "late") stats.late++;
  });

  const sortedWeeks = Array.from(weekMap.entries()).sort(
    ([a], [b]) => new Date(a).getTime() - new Date(b).getTime()
  );

  sortedWeeks.forEach(([week, stats]) => {
    const weekDate = new Date(week);
    weeklyData.push({
      week: weekDate.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      }),
      ...stats,
    });
  });

  return weeklyData;
};

export const getTodayStats = (records: AttendanceRecord[]) => {
  const today = dates[dates.length - 1];
  const todayRecords = records.filter((r) => r.date === today);

  return {
    total: todayRecords.length,
    present: todayRecords.filter((r) => r.status === "present").length,
    absent: todayRecords.filter((r) => r.status === "absent").length,
    late: todayRecords.filter((r) => r.status === "late").length,
    date: today,
  };
};
